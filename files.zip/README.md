# 🎙️ Speech to Text — Python App

Ứng dụng chuyển giọng nói thành văn bản, hỗ trợ **tiếng Việt** và 7 ngôn ngữ khác.

## Cài đặt

### 1. Tạo virtual environment

```bash
python -m venv venv
source venv/bin/activate        # macOS/Linux
venv\Scripts\activate           # Windows
```

### 2. Cài dependencies

```bash
pip install -r requirements.txt
```

> **macOS** — cần cài thêm PortAudio cho microphone:
> ```bash
> brew install portaudio
> ```

> **Ubuntu/Debian:**
> ```bash
> sudo apt install python3-pyaudio portaudio19-dev ffmpeg
> ```

> **Windows:** PyAudio thường cài trực tiếp qua pip không cần thêm gì.

---

## Chạy Web App

```bash
python app.py
```

Truy cập: http://localhost:5000

**Tính năng:**
- 🎤 Ghi âm trực tiếp từ microphone trình duyệt
- 📁 Upload file audio (WAV, MP3, FLAC, OGG, M4A)
- 📋 Lịch sử các lần nhận dạng
- 🌐 Hỗ trợ 8 ngôn ngữ

---

## Dùng CLI (Terminal)

```bash
# Chuyển file audio
python cli.py audio.wav
python cli.py audio.mp3 --lang en-US

# Ghi âm từ microphone
python cli.py --mic
python cli.py --mic --lang ja-JP

# Lưu kết quả ra file
python cli.py audio.wav --output result.txt
```

---

## Ngôn ngữ hỗ trợ

| Mã | Ngôn ngữ |
|----|----------|
| `vi-VN` | Tiếng Việt |
| `en-US` | English (US) |
| `en-GB` | English (UK) |
| `ja-JP` | 日本語 |
| `ko-KR` | 한국어 |
| `zh-CN` | 中文 (简体) |
| `fr-FR` | Français |
| `de-DE` | Deutsch |

---

## Nâng cấp lên Google Cloud Speech API (chính xác hơn)

Thay `recognize_google()` bằng `recognize_google_cloud()`:

```python
# Trong app.py
text = recognizer.recognize_google_cloud(
    audio_data,
    credentials_json=open("service_account.json").read(),
    language=language
)
```

Cần có file `service_account.json` từ Google Cloud Console.
