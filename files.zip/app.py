"""
Speech-to-Text Web App
Sử dụng Flask + Google Speech Recognition (miễn phí)
"""

from flask import Flask, render_template, request, jsonify
import speech_recognition as sr
import os
import tempfile

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max

recognizer = sr.Recognizer()

SUPPORTED_LANGUAGES = {
    "vi-VN": "Tiếng Việt",
    "en-US": "English (US)",
    "en-GB": "English (UK)",
    "ja-JP": "日本語",
    "ko-KR": "한국어",
    "zh-CN": "中文 (简体)",
    "fr-FR": "Français",
    "de-DE": "Deutsch",
}

@app.route("/")
def index():
    return render_template("index.html", languages=SUPPORTED_LANGUAGES)


@app.route("/transcribe", methods=["POST"])
def transcribe():
    """Nhận file audio và trả về text."""
    if "audio" not in request.files:
        return jsonify({"error": "Không tìm thấy file audio"}), 400

    audio_file = request.files["audio"]
    language = request.form.get("language", "vi-VN")

    if audio_file.filename == "":
        return jsonify({"error": "File trống"}), 400

    # Lưu file tạm
    suffix = os.path.splitext(audio_file.filename)[1] or ".wav"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        audio_file.save(tmp.name)
        tmp_path = tmp.name

    try:
        with sr.AudioFile(tmp_path) as source:
            # Lọc noise
            recognizer.adjust_for_ambient_noise(source, duration=0.5)
            audio_data = recognizer.record(source)

        # Dùng Google Speech Recognition (miễn phí, giới hạn request)
        text = recognizer.recognize_google(audio_data, language=language)
        return jsonify({"text": text, "language": language})

    except sr.UnknownValueError:
        return jsonify({"error": "Không nhận ra giọng nói. Hãy nói rõ hơn."}), 422
    except sr.RequestError as e:
        return jsonify({"error": f"Lỗi kết nối Google API: {e}"}), 503
    except Exception as e:
        return jsonify({"error": f"Lỗi xử lý: {str(e)}"}), 500
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)


@app.route("/transcribe-mic", methods=["POST"])
def transcribe_mic():
    """Nhận audio base64 từ microphone trình duyệt."""
    import base64
    import io

    data = request.get_json()
    if not data or "audio" not in data:
        return jsonify({"error": "Không có dữ liệu audio"}), 400

    language = data.get("language", "vi-VN")

    try:
        # Decode base64 audio (WebM/Opus từ browser)
        audio_bytes = base64.b64decode(data["audio"].split(",")[-1])

        with tempfile.NamedTemporaryFile(delete=False, suffix=".webm") as tmp:
            tmp.write(audio_bytes)
            tmp_path = tmp.name

        # Convert WebM → WAV bằng pydub
        from pydub import AudioSegment
        audio = AudioSegment.from_file(tmp_path)
        wav_path = tmp_path.replace(".webm", ".wav")
        audio.export(wav_path, format="wav")

        with sr.AudioFile(wav_path) as source:
            recognizer.adjust_for_ambient_noise(source, duration=0.3)
            audio_data = recognizer.record(source)

        text = recognizer.recognize_google(audio_data, language=language)
        return jsonify({"text": text})

    except sr.UnknownValueError:
        return jsonify({"error": "Không nhận ra giọng nói"}), 422
    except sr.RequestError as e:
        return jsonify({"error": f"Lỗi API: {e}"}), 503
    except Exception as e:
        return jsonify({"error": f"Lỗi: {str(e)}"}), 500
    finally:
        for p in [tmp_path, wav_path if "wav_path" in dir() else ""]:
            if p and os.path.exists(p):
                os.unlink(p)


if __name__ == "__main__":
    print("🎙️  Speech-to-Text App đang chạy tại http://localhost:5000")
    app.run(debug=True, port=5000)
