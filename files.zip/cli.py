"""
Speech-to-Text CLI — dùng trực tiếp từ terminal
Dùng: python cli.py [file_audio] hoặc python cli.py --mic
"""

import speech_recognition as sr
import argparse
import sys
import os


def transcribe_file(filepath: str, language: str = "vi-VN") -> str:
    """Chuyển đổi file audio thành text."""
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Không tìm thấy file: {filepath}")

    recognizer = sr.Recognizer()
    print(f"📂 Đang đọc file: {filepath}")

    with sr.AudioFile(filepath) as source:
        recognizer.adjust_for_ambient_noise(source, duration=0.5)
        audio = recognizer.record(source)

    print("🔄 Đang nhận dạng...")
    text = recognizer.recognize_google(audio, language=language)
    return text


def transcribe_microphone(language: str = "vi-VN", timeout: int = 5) -> str:
    """Ghi âm từ microphone và chuyển đổi thành text."""
    recognizer = sr.Recognizer()

    with sr.Microphone() as source:
        print("🎤 Đang hiệu chỉnh môi trường...")
        recognizer.adjust_for_ambient_noise(source, duration=1)
        print("🟢 Bắt đầu nói! (sẽ tự dừng sau khi im lặng)")
        try:
            audio = recognizer.listen(source, timeout=timeout, phrase_time_limit=30)
        except sr.WaitTimeoutError:
            raise RuntimeError("Hết thời gian chờ, không phát hiện giọng nói")

    print("🔄 Đang nhận dạng...")
    text = recognizer.recognize_google(audio, language=language)
    return text


def main():
    parser = argparse.ArgumentParser(
        description="🎙️ Speech-to-Text CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ví dụ:
  python cli.py audio.wav
  python cli.py audio.mp3 --lang en-US
  python cli.py --mic
  python cli.py --mic --lang ja-JP
        """
    )
    parser.add_argument("file", nargs="?", help="File audio cần chuyển đổi (WAV, MP3, FLAC...)")
    parser.add_argument("--mic", action="store_true", help="Ghi âm từ microphone")
    parser.add_argument("--lang", default="vi-VN", help="Mã ngôn ngữ (mặc định: vi-VN)")
    parser.add_argument("--output", "-o", help="Lưu kết quả ra file .txt")

    args = parser.parse_args()

    if not args.file and not args.mic:
        parser.print_help()
        sys.exit(1)

    try:
        if args.mic:
            text = transcribe_microphone(language=args.lang)
        else:
            text = transcribe_file(args.file, language=args.lang)

        print("\n" + "─" * 50)
        print("📝 Kết quả:")
        print(text)
        print("─" * 50)

        if args.output:
            with open(args.output, "w", encoding="utf-8") as f:
                f.write(text)
            print(f"\n✅ Đã lưu vào: {args.output}")

    except sr.UnknownValueError:
        print("❌ Không nhận ra giọng nói. Hãy nói rõ hơn.")
        sys.exit(1)
    except sr.RequestError as e:
        print(f"❌ Lỗi kết nối Google API: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Lỗi: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
